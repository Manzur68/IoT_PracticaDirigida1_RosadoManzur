import network
import time
import ujson
import dht
from machine import Pin
from umqtt.simple import MQTTClient

DHT_PIN = 15
LED_PIN = 2

sensor = dht.DHT22(Pin(DHT_PIN))
led = Pin(LED_PIN, Pin.OUT)
led.value(0)

BROKER = "broker.hivemq.com"
PORT = 8883
TOPIC_PUB = "casa/temperatura"
TOPIC_SUB = "casa/led"
CLIENT_ID = "ESP32_MicroPython_Wokwi"

def conectar_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print("Conectando a WiFi Wokwi: ")
        wlan.connect("Wokwi-GUEST", "")
        while not wlan.isconnected():
            time.sleep(0.5)
            print(".", end="")
    print("\nWiFi Conectado IP:", wlan.ifconfig()[0])

def sub_cb(topic, msg):
    t = topic.decode('utf-8')
    m = msg.decode('utf-8')
    print(f"\n[Mensaje recibido en {t}]: {m}")
    
    if t == TOPIC_SUB:
        if m == "ON":
            led.value(1)
            print("-LED Encendido")
        elif m == "OFF":
            led.value(0)
            print("-LED Apagado")
conectar_wifi()
print("Conectando al Broker MQTT con TLS:")
client = MQTTClient(
    client_id=CLIENT_ID,
    server=BROKER,
    port=PORT,
    ssl=True,
    ssl_params={'server_hostname': BROKER}
)
client.set_callback(sub_cb)
client.connect()
client.subscribe(TOPIC_SUB)
print(f"Conectado Suscrito a '{TOPIC_SUB}'")

last_pub = 0

while True:
    try:
        client.check_msg()
        if time.time() - last_pub >= 5:
            last_pub = time.time()
            sensor.measure()
            t = sensor.temperature()
            h = sensor.humidity()
            data = {
                "temp": t,
                "hum": h
            }
            payload = ujson.dumps(data)
            
            print(f"Publicando en {TOPIC_PUB}: {payload}")
            client.publish(TOPIC_PUB, payload)
            
    except Exception as e:
        print("Error en el bucle principal:", e)
        time.sleep(1)